#How to run:
    python WaterTreatment.py

#Dependencies:
    import numpy as np # linear algebra
from keras.models import Model
from keras.layers import Input, Dense
from matplotlib import pyplot as plt
import math
import copy
import pickle
import random
import hashlib
import numpy as np
import pandas as pd
import numpy as np
from matplotlib import pyplot as plt
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
from yellowbrick.cluster import KElbowVisualizer
import sklearn.metrics as mse

# Additional:
    please keep all files in same folder